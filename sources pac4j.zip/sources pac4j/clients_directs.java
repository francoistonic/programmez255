final DirectBasicAuthClient basicAuthClient = new DirectBasicAuthClient(new SimpleTestUsernamePasswordAuthenticator());

final JwtAuthenticator jwtAuthenticator = new JwtAuthenticator(new SecretSignatureConfiguration(salt));
final HeaderClient headerClient = new HeaderClient("Authorization", jwtAuthenticator);

final Clients clients = new Clients(basicAuthClient, headerClient);
