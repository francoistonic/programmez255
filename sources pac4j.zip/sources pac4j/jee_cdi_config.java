package org.pac4j.demo.jee;

import org.pac4j.cas.client.CasClient;
import org.pac4j.cas.config.CasConfiguration;
import org.pac4j.core.client.Clients;
import org.pac4j.core.config.Config;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;

@Dependent
public class SecurityConfig {

    @Produces @ApplicationScoped
    private Config buildConfiguration() {
        final CasConfiguration configuration = new CasConfiguration("https://casserverpac4j.herokuapp.com/login");
        final CasClient casClient = new CasClient(configuration);

        final Clients clients = new Clients("http://localhost:8080/callback", casClient);

        return new Config(clients);
    }
}
