config.addMatcher("excludePaths", new PathMatcher().excludePaths("/callback", "/img", "/css", "/js", "/public"));

...

new SecurityFilter(config, "CasClient", null, "excludePaths");
