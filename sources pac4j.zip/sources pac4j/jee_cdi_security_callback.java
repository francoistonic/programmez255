package org.pac4j.demo.jee;

import org.pac4j.core.config.Config;
import org.pac4j.jee.filter.CallbackFilter;
import org.pac4j.jee.filter.SecurityFilter;
import org.pac4j.jee.util.FilterHelper;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.context.Initialized;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletContext;

@Named
@ApplicationScoped
public class WebConfig {

    @Inject
    private Config config;

    public void build(@Observes @Initialized(ApplicationScoped.class) ServletContext servletContext) {

        final FilterHelper filterHelper = new FilterHelper(servletContext);

        final SecurityFilter casFilter = new SecurityFilter(config, "CasClient");
        filterHelper.addFilterMapping("securityFilter", casFilter, "/private/*");

        final CallbackFilter callbackFilter = new CallbackFilter(config, "/");
        filterHelper.addFilterMapping("callbackFilter", callbackFilter, "/callback");
    }
}
