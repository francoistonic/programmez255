registry.addInterceptor(
        new SecurityInterceptor(config, "SAML2Client", "admin")
).addPathPatterns("/admin/*");
