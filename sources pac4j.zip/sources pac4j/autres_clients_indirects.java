final FacebookClient facebookClient = new FacebookClient(facebookKey, facebookSecret);
final TwitterClient twitterClient = new TwitterClient(twitterKey, twitterSecret);

final OidcConfiguration oidcConfiguration = new OidcConfiguration();
oidcConfiguration.setClientId(clientId);
oidcConfiguration.setSecret(clientSecret);
oidcConfiguration.setDiscoveryURI("https://accounts.google.com/.well-known/openid-configuration");
oidcConfiguration.setUseNonce(true);
oidcConfiguration.addCustomParam("prompt", "consent");
final OidcClient oidcClient = new OidcClient(oidcConfiguration);

final SAML2Configuration cfg = new SAML2Configuration("resource:samlKeystore.jks", "pac4j-demo-passwd",
        "pac4j-demo-passwd", "resource:metadata-okta.xml");
cfg.setMaximumAuthenticationLifetime(3600);
cfg.setServiceProviderEntityId("http://localhost:8080/callback?client_name=SAML2Client");
cfg.setServiceProviderMetadataPath("file:/etc/local/saml/sp-metadata.xml");
final SAML2Client saml2Client = new SAML2Client(cfg);

final Clients clients = new Clients("http://localhost:8080/callback", facebookClient, twitterClient, oidcClient, saml2Client);
