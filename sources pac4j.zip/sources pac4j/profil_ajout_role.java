client.setAuthorizationGenerator((ctx, session, profile) -> {
    if (profile.getId().equals("jerome")) {
        profile.addRole("ROLE_ADMIN");
    } else {
        profile.addRole("ROLE_USER");
    }
    return Optional.of(profile);
});
