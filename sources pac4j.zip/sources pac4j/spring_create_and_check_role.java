registry.addInterceptor(
        SecurityInterceptor.build(config, "SAML2Client", new RequireAnyRoleAuthorizer("ROLE_ADMIN"))
).addPathPatterns("/admin/*");
