﻿namespace DemoKaibay.Models
{
    public class KaibayConsts
    {

        public const int MaxTitleLength = 32;

        public const int MaxDescriptionLength = 180;
    }
}